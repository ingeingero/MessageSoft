package net.learn2develop.JSON;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;



import android.app.Activity;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

public class JSONActivity extends Activity  {

	  public String RESTService(String [] params) {

	        HttpURLConnection urlConnection = null;
	        BufferedReader reader = null;
	        String FORECAST_BASE_URL="http://www.solucionesapps.com/zona_amigos/users/list.php";	
	        String QUERY_PARAM="id";
	        String FORMAT_PARAM="mode";
	        String UNITS_PARAM="units";
	        String DAYS_PARAM="cnt";
	        String format="json";
	        String units="metric";
	        Integer numDays=7;

	        Uri builtUri= Uri.parse(FORECAST_BASE_URL).buildUpon()
	                .appendQueryParameter(QUERY_PARAM,"3").build();
	                /*.appendQueryParameter(FORMAT_PARAM,format)
	                .appendQueryParameter(UNITS_PARAM,params[1])
	                .appendQueryParameter(DAYS_PARAM,Integer.toString(numDays)).build();*/

	        // Will contain the raw JSON response as a string.
	        String jsonStr = null;

	        try {
	            // Construct the URL for the OpenWeatherMap query
	            // Possible parameters are available at OWM's forecast API page, at
	            // http://openweathermap.org/API#forecast
	            Log.v("testWS","Forecast URL: "+ builtUri.toString());
	            URL url = new URL(builtUri.toString());

	            // Create the request to OpenWeatherMap, and open the connection
	            urlConnection = (HttpURLConnection) url.openConnection();
	            urlConnection.setRequestMethod("GET");
	            urlConnection.connect();

	            // Read the input stream into a String
	            InputStream inputStream = urlConnection.getInputStream();
	            StringBuffer buffer = new StringBuffer();
	            if (inputStream == null) {
	                // Nothing to do.
	                return null;
	            }
	            reader = new BufferedReader(new InputStreamReader(inputStream));

	            String line;
	            while ((line = reader.readLine()) != null) {
	                // Since it's JSON, adding a newline isn't necessary (it won't affect parsing)
	                // But it does make debugging a *lot* easier if you print out the completed
	                // buffer for debugging.
	                buffer.append(line + "\n");
	            }

	            if (buffer.length() == 0) {
	                // Stream was empty.  No point in parsing.
	               return null;
	            }
	            jsonStr = buffer.toString();
	            Log.v("testWS","Forecast JSON String: "+ jsonStr);
	            return jsonStr;
	        } catch (IOException e) {
	            Log.e("PlaceholderFragment", "Error ", e);
	            // If the code didn't successfully get the weather data, there's no point in attempting
	            // to parse it.
	            return null;
	        } finally{
	            if (urlConnection != null) {
	                urlConnection.disconnect();
	            }
	            if (reader != null) {
	                try {
	                    reader.close();
	                } catch (final IOException e) {
	                    Log.e("PlaceholderFragment", "Error closing stream", e);
	                }
	            }
	        }
	    }
	  
	
    private class ReadJSONFeedTask extends AsyncTask<String, Void, String> {
        protected String doInBackground(String... params) {
            return RESTService(params);
        }
        
        protected void onPostExecute(String result) {
        String result1 = result.substring(14, result.length()-3);
      // result = "{'id':'2','nombres':'edilson','apellidos':'laverdemolina','telefono':'3124408995','email':'elaverde6@misena.edu.co','latitud':'0','longitud':'0','fecha':'0000-00-00','hora':'00:00:00'}";
        GsonBuilder builder = new GsonBuilder();
        Gson gson = builder.create();
        usuarios parsedData = gson.fromJson(result1, usuarios.class);	
        TextView nombres = (TextView)findViewById(R.id.nombres);
        TextView apellidos = (TextView)findViewById(R.id.apellidos);
        TextView telefono = (TextView)findViewById(R.id.telefono);
        TextView email = (TextView)findViewById(R.id.email);
        TextView latitud = (TextView)findViewById(R.id.latitud);
        TextView longitud = (TextView)findViewById(R.id.longitud);
        TextView fecha = (TextView)findViewById(R.id.fecha);
        TextView hora = (TextView)findViewById(R.id.hora);
        
		 nombres.setText("Nombre :"+parsedData.nombres);
		 apellidos.setText("Apellido :"+parsedData.apellidos);
		 telefono.setText("Telefono :"+parsedData.telefono);
		 email.setText("e mail :"+parsedData.email);
		 latitud.setText("Latitud :"+parsedData.latitud);
		 longitud.setText("Longitud :"+parsedData.longitud);
		 fecha.setText("Fecha :"+parsedData.fecha);
		 hora.setText("Hora :"+parsedData.hora);
		// System.out.println(result1);
      //  Toast.makeText(getBaseContext(), result+"", Toast.LENGTH_LONG).show();
        	
        }
    }

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		
	
		new ReadJSONFeedTask().execute("http://www.solucionesapps.com/zona_amigos/users/list.php?id=ALL");
	}
}