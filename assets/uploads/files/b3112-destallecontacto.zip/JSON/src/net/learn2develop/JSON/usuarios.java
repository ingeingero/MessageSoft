package net.learn2develop.JSON;

public class usuarios {
	int id;
    String nombres;
    String apellidos;
    String telefono;
    String email;
    String latitud;
    String longitud;
    String fecha;
    String hora;
 
    public int getId() {  
    	  return id;  
    	 }  
    public String getLastName() {  
    	  return apellidos;  
    	 }  
}

